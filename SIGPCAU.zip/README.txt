Compilar: gcc -o sigpcau main.c
Ejecutar: ./sigpcau
